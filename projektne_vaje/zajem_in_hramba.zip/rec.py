import os
import glob
import sys

try:
    sys.path.append(glob.glob('../PythonAPI/carla/dist/carla-*%d.%d-%s.egg' % (
        sys.version_info.major,
        sys.version_info.minor,
        'win-amd64' if os.name == 'nt' else 'linux-x86_64'))[0])
except IndexError:
    pass


import carla
import random
import queue
import numpy as np
import copy
import cv2
import time
import matplotlib.pyplot as plt
import h5py

WIDTH = 640
HEIGHT = 384

### Helper functions
def to_bgra_array(image):
    """Convert a CARLA raw image to a BGRA numpy array."""
    array = np.frombuffer(image.raw_data, dtype=np.dtype("uint8"))
    array = np.reshape(array, (image.height, image.width, 4))
    return array

def to_rgb_array(image):
    """Convert a CARLA raw image to a RGB numpy array."""
    array = to_bgra_array(image)
    # Convert BGRA to RGB.
    array = array[:, :, :3]
    array = array[:, :, ::-1]
    return array

def convert_rgb_bgr(array):
    """numpy array: RGB <=> BGR"""
    return array[:, :, ::-1].copy()


if __name__ == "__main__":
    client = carla.Client("localhost", 2000)
    world = client.get_world()

    blueprint_library = world.get_blueprint_library()
    bp = blueprint_library.filter("vehicle")[0]

    # Random spawn point
    transform = random.choice(world.get_map().get_spawn_points()) 

    # Spawn a vehicle
    actor_list = []
    vehicle = world.spawn_actor(bp, transform) 
    actor_list.append(vehicle)

    vehicle.set_autopilot(True)

    ### CAMERA
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    # Modify the attributes of the blueprint to set image resolution and field of view.
    camera_bp.set_attribute('image_size_x', f'{WIDTH}')
    camera_bp.set_attribute('image_size_y', f'{HEIGHT}')

    camera_transform = carla.Transform(carla.Location(x=1.5, z=2.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    image_queue = queue.LifoQueue()
    camera.listen(image_queue.put)
    actor_list.append(camera)

    ### LIDAR
    lidar_bp = blueprint_library.find('sensor.lidar.ray_cast')
    # Modify the attributes of the blueprint to set image resolution and field of view.
    lidar_bp.set_attribute('rotation_frequency', '10')

    lidar_transform = carla.Transform(carla.Location(x=1.5, z=2.4))
    lidar = world.spawn_actor(lidar_bp, lidar_transform, attach_to=vehicle)
    lidar_queue = queue.LifoQueue()
    lidar.listen(lidar_queue.put)
    actor_list.append(lidar)
    

    with h5py.File('data_file.hdf5', 'w') as file_obj:
        ind = 0
        sig_list = []
        speed_list = []
        # Main loop
        while True:
            vehicles = []

            ### LIDAR logic
            lidar_measurement = lidar_queue.get()
            #for location in lidar_measurement:
            #    print(location)

            lidar_range = 50
            points = np.frombuffer(lidar_measurement.raw_data, dtype=np.dtype('f4'))
            points = np.reshape(points, (int(points.shape[0] / 4), 4))
            lidar_data = np.array(points[:, :2])
            lidar_data *= min(WIDTH, HEIGHT) / (2.0 * lidar_range)
            lidar_data += (0.5 * WIDTH, 0.5 * HEIGHT)
            lidar_data = np.fabs(lidar_data)  # pylint: disable=E1111
            lidar_data = lidar_data.astype(np.int32)
            lidar_data = np.reshape(lidar_data, (-1, 2))
            lidar_img_size = (WIDTH, HEIGHT, 3)
            lidar_img = np.zeros((lidar_img_size), dtype=np.uint8)
            lidar_img[tuple(lidar_data.T)] = (255, 255, 255)
            cv2.imshow("lidar_frame", lidar_img)

            ### HITROST
            carla_velocity_vec3 = vehicle.get_velocity()
            vec4 = np.array([carla_velocity_vec3.x,
                             carla_velocity_vec3.y,
                             carla_velocity_vec3.z, 1]).reshape(4, 1)
            carla_trans = np.array(vehicle.get_transform().get_matrix())
            carla_trans.reshape(4, 4)
            carla_trans[0:3, 3] = 0.0
            vel_in_vehicle = np.linalg.inv(carla_trans) @ vec4
            speed = vel_in_vehicle[0]
            print(f'HITROST {speed}')
            speed_list.append(speed)

            ### IMG logic
            image = image_queue.get()
            data = to_rgb_array(image)

            bgr_img = to_rgb_array(image)
            rgb_img = convert_rgb_bgr(bgr_img)

            frame = rgb_img
            
            # Shrani LIDAR signal
            s = lidar_img

            sig_list.append(s)

            # Shranemo posamezno sliko iz kamere, kompromis
            # med porabo RAM pri nalaganju in prostora na disku
            file_obj[f'camera_main/{ind}'] = frame

            ind += 1

            cv2.imshow("frame", rgb_img)

            if cv2.waitKey(10) & 0xFF == ord('q'):
                break
            

        file_obj['camera_main'].attrs['n_frames'] = ind
        file_obj['camera_main'].attrs['fvz'] = 10

        file_obj['lidar_full'] = np.array(sig_list)
        file_obj['speed_full'] = np.array(speed_list)

        #file_obj['camera_main_full'].attrs['fvz'] = 30 


    for a in actor_list:
        a.destroy()

