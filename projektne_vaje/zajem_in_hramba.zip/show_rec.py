import cv2 # knjiznica za zajem spletne kamere

import numpy as np
import h5py
import matplotlib.pyplot as plt

WIDTH = 640
HEIGHT = 384


def update_line(hl, new_data, ind):
    hl.set_xdata(np.append(hl.get_xdata(), ind))
    hl.set_ydata(np.append(hl.get_ydata(), new_data))
    plt.draw()

with h5py.File('data_file.hdf5', 'r') as file_obj:
    N = file_obj['camera_main'].attrs['n_frames']
    fvz = file_obj['camera_main'].attrs['fvz']

    sleep_time_ms = int((1/fvz) * 1000)
    print(sleep_time_ms)
    sleep_time_ms -= 1

    speed_list = file_obj['speed_full']

    plt.xlim(0,N) 
    plt.ylim(0,100)
    hl, = plt.plot([], [])
    #plt.plot(speed_list)
    #plt.show()
    for n in range(0, N):
        ### CAMERA
        frame = np.array(file_obj[f'camera_main/{n}'])

        lidar_img = np.array(file_obj['lidar_full'])
    #for lidar_frame in lidar_img:
        ### LIDAR
        '''
        lidar_data = np.array(points[:, :2])
        lidar_data *= min(WIDTH, HEIGHT) / (2.0 * lidar_range)
        lidar_data += (0.5 * WIDTH, 0.5 * HEIGHT)
        lidar_data = np.fabs(lidar_data)  # pylint: disable=E1111
        lidar_data = lidar_data.astype(np.int32)
        lidar_data = np.reshape(lidar_data, (-1, 2))
        lidar_img_size = (WIDTH, HEIGHT, 3)
        lidar_img = np.zeros((lidar_img_size), dtype=np.uint8)
        lidar_img[tuple(lidar_data.T)] = (255, 255, 255)
        '''

        cv2.imshow('frame', frame)
        cv2.imshow("lidar_frame", lidar_img[n])

        update_line(hl, speed_list[n], n)
        plt.pause(0.001)

        if cv2.waitKey(sleep_time_ms) & 0xFF == ord('q'):
            break
