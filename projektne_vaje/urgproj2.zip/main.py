import os
import glob
import sys

try:
    sys.path.append(glob.glob('../PythonAPI/carla/dist/carla-*%d.%d-%s.egg' % (
        sys.version_info.major,
        sys.version_info.minor,
        'win-amd64' if os.name == 'nt' else 'linux-x86_64'))[0])
except IndexError:
    pass


import carla
import random
import queue
import numpy as np
import copy
import cv2
import time
import torch
import matplotlib.pyplot as plt
import math
#import object_detection

import lane_detection
import detect_trafficLights
import drivable_detect
import pygame
from copy import deepcopy

WIDTH = 640
HEIGHT = 384

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
DARK_PEACH = (167, 106, 134)
PETAL_PINK = (246,196,255)
DEFAULT_BUTTON_COLOR=(106, 127, 149)
HOVERED_BUTTON_COLOR=(152, 182, 214)
LIGHT_ORANGE = (202, 164, 97)

#pygame.init()
#win = pygame.display.set_mode((WIDTH, HEIGHT))
#pygame.display.set_caption("GUI")
#win.fill(DARK_PEACH)
#normalFont = pygame.font.Font('freesansbold.ttf', 25)
#smallFont = pygame.font.Font('freesansbold.ttf', 18)

np.seterr(divide='ignore', invalid='ignore')
# Load model
#model = torch.hub.load('ultralytics/yolov5', 'yolov5s')  # yolov5n, yolov5x6, custom
#torch.save(model, 'model.pth')

#model2 = torch.hub.load('datvuthanh/hybridnets', 'hybridnets', pretrained=True)
#torch.save(model2, 'hybridnets.pth')

### Helper functions
def to_bgra_array(image):
    """Convert a CARLA raw image to a BGRA numpy array."""
    array = np.frombuffer(image.raw_data, dtype=np.dtype("uint8"))
    array = np.reshape(array, (image.height, image.width, 4))
    return array

def to_rgb_array(image):
    """Convert a CARLA raw image to a RGB numpy array."""
    array = to_bgra_array(image)
    # Convert BGRA to RGB.
    array = array[:, :, :3]
    array = array[:, :, ::-1]
    return array

def convert_rgb_bgr(array):
    """numpy array: RGB <=> BGR"""
    return array[:, :, ::-1].copy()

def recognizeFromImage(img):
    ...
    #return model(img)



if __name__ == "__main__":
    client = carla.Client("localhost", 2000)
    world = client.get_world()

    blueprint_library = world.get_blueprint_library()
    # Random vehicle
    #bp = random.choice(blueprint_library.filter("vehicle"))
    #print(blueprint_library.filter("vehicle"))
    bp = blueprint_library.filter("vehicle")[0]

    # Random spawn point
    transform = random.choice(world.get_map().get_spawn_points()) 

    # Spawn a vehicle
    actor_list = []
    vehicle = world.spawn_actor(bp, transform) 
    actor_list.append(vehicle)

    vehicle.set_autopilot(True)

    ### CAMERA
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    # Modify the attributes of the blueprint to set image resolution and field of view.
    camera_bp.set_attribute('image_size_x', f'{WIDTH}')
    camera_bp.set_attribute('image_size_y', f'{HEIGHT}')

    camera_transform = carla.Transform(carla.Location(x=1.5, z=2.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    image_queue = queue.LifoQueue()
    camera.listen(image_queue.put)
    actor_list.append(camera)

    ### LIDAR
    lidar_bp = blueprint_library.find('sensor.lidar.ray_cast')
    # Modify the attributes of the blueprint to set image resolution and field of view.
    lidar_bp.set_attribute('rotation_frequency', '10')

    lidar_transform = carla.Transform(carla.Location(x=1.5, z=2.4))
    lidar = world.spawn_actor(lidar_bp, lidar_transform, attach_to=vehicle)
    lidar_queue = queue.LifoQueue()
    lidar.listen(lidar_queue.put)
    actor_list.append(lidar)
    

    # Main loop
    while True:
        vehicles = []

        ### LIDAR logic
        lidar_measurement = lidar_queue.get()
        #for location in lidar_measurement:
        #    location

        lidar_range = 20 
        points = np.frombuffer(lidar_measurement.raw_data, dtype=np.dtype('float32'))
        points = np.reshape(points, (int(points.shape[0] / 4), 4))
        lidar_data = np.array(points[:, :2])
        lidar_data *= min(WIDTH, HEIGHT) / (2.0 * lidar_range)
        lidar_data += (0.5 * HEIGHT, 0.5 * WIDTH)
        lidar_data = np.fabs(lidar_data)  # pylint: disable=E1111
        lidar_data = lidar_data.astype(np.int32)
        lidar_data = np.reshape(lidar_data, (-1, 2))

        #print(lidar_data.tolist())
        #jarvis(lidar_data)


        lidar_img_size = (HEIGHT, WIDTH, 3)
        lidar_img = np.zeros((lidar_img_size), dtype=np.uint8)
        lidar_img[tuple(lidar_data.T)] = (255, 255, 255)
        
        lidar_img = np.flip(lidar_img, axis=0)

        ### LIDAR IMG
        src = lidar_img
        gray = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY)
        blur = cv2.blur(gray, (3, 3)) # blur the image
        ret, thresh = cv2.threshold(blur, 50, 255, cv2.THRESH_BINARY)
        contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        hull = []
        for i in range(len(contours)):
            hull.append(cv2.convexHull(contours[i], False))

        drawing = np.zeros((thresh.shape[0], thresh.shape[1], 3), np.uint8)
        for i in range(len(contours)):
            color_contours = (0, 255, 0) # green - color for contours
            color = (255, 0, 0) # blue - color for convex hull
            cv2.drawContours(drawing, contours, i, color_contours, 1, 8, hierarchy)
            cv2.drawContours(drawing, hull, i, color, 1, 8)

        cv2.imshow("convx", drawing)
        cv2.imshow("lidar_frame", lidar_img)

        ### IMG logic
        image = image_queue.get()
        data = to_rgb_array(image)

        bgr_img = to_rgb_array(image)
        rgb_img = convert_rgb_bgr(bgr_img)
        
        cv2.imshow("frame", rgb_img)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    for a in actor_list:
        a.destroy()

