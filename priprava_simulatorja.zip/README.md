# Osnovne informacije

## Datoteke

"data.txt" - vsebuje zajete podatke v človeško berljivi obliki
"controlCar_saveData.py" - Python program, ki se poveže na instanco carla strežnika. Omogoča vožnjo vozila ter shranjuje podatke v "data.txt" in "captured". **Od zagona do zaključka shranjuje podatke**
"captured" - mapa, v katero se shranjujejo slike, ki pridejo iz simulatorja v formatu jpeg

## Zagon

```sh
python3 controlCar_saveData.py
```
***Ob vsakem ponovnem zagonu se datoteka "data.txt" prepiše z novimi podatki, mapa "captured" pa se zbriše ter ponovno ustvari ter napolni z slikami!***

## V aplikaciji

- W = naprej
- A = levo
- S = nazaj
- D = desno
- SPACE = ročna zavora
- ESC = zaključek programa

## Podrobnost oddanega zip arhiva

v mapi "captured" je odstranjeno toliko slik, da je arhiv za oddajo primerno velik. V splošnem se shrani vsak frame simulacije kot svoja slika.

