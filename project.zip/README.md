# Integracija in demonstracija avtonomne vožnje

## Datoteke
- "vozlisce/" - direktorij, ki vsebuje vse datoteke povezane z vozliščem
- "demos/" - direktorij, ki vsebuje demo delovanja
- "detect_[ime]" - koda za prepoznavanje [imena]
- "vozlisce.py" - Kontrolno vozlišče, preko katerega teče client instanca carla simulatorja, zaznavanje tipkovnice in logika vožnje
- "requirements.txt" - datoteka, ki vsebuje verzije potrebnih pip paketov za python virtualno okolje
- "README.md" - ta datoteka, opisuje zagon, upravljanje in delovanje ostalih datotek
## Zagon
1. Nameščeno priloženo virtualno okolje
	```sh
	python3 -m venv carla_environment
	source carla_environment/bin/activate
	pip install -r requirements.txt
	```
2. Nameščen simulator carla in verzija 0.9.13 python paketa carla (https://carla.readthedocs.io/en/latest/start_quickstart/)
3. Nameščen pyTorch verzije, ki jo vaš PC podpira (https://pytorch.org/get-started/locally/https://pytorch.org/get-started/locally/)
4. Zagon carla serverja iz root direktorija simulatorja (namesto Low lahko uporabite Epic če računalnik premore)
	```sh
	./CarlaUE4.sh -quality-level=Low
	```
5. Zagon vozlišča (s priloženim virtualnim okoljem, ki ima nameščeno carlo in pyTorch)
	```sh
	python3 vozlisce.py
	```

## V aplikaciji

- W = naprej
- A = levo
- S = nazaj
- D = desno
- SPACE = ročna zavora
- ESC = zaključek programa
- T = vklop zaznavanje objektov
- F = izklop zaznavanje objektov
- P = vklop / izklop avtonomne vožnje
- G = vklop zaznavanja cestišča / pasov
- H = izklop zaznavanja cestišča / pasov

## Uporabne informacije
- Ob prvotnem zagonu vozlišča se bodo prenesli modeli, uporabljeni za zaznavanje
- Ko je vklopljena avtonomna vožnja, je ročno krmiljenje vozila onemogočeno
- Tipke za izklop je včasih potrebno pritisniti za malenkost dlje kot navaden klik, da so registrirane (zaradi obremenjenosti)
- Tipka za vkop / izklop avtonomne vožnje je extremno reaktivna, če ni vklopljeno nobeno zaznavanje, kar pomeni da se lahko več krat aktivira že ob hitrem enojnem kliku (zaradi tega v zgornjem levem kotu program prikazuje stanje trenutno vklopljenih stvari)
- Vsa proizvodnja in testiranje je bilo izvedeno  ***samo*** v okolju Linux

## Kontakt
V primeru težav lahko kontaktirate katerokoli izmed naštetih oseb (npr za videoposnetke, ki so bili preveliki za oddajo preko strani vaje.um.si):
- Alex Brence (alex.brence@student.um.si)
- Ivor Canjuga (ivor.canjuga@student.um.si)
- Tobias Korže (tobias.korze1@student.um.si)
