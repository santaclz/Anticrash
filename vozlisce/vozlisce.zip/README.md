# Priprava kontrolnega vozlišča

## Datoteke

- "detect_<ime>" - koda za prepoznavanje <ime>, vrne python list
- "vozlisce.py" - Kontrolno vozlišče, preko katerega vse teče

## Zagon

```sh
python3 vozlisce.py
```

## V aplikaciji

- W = naprej
- A = levo
- S = nazaj
- D = desno
- SPACE = ročna zavora
- ESC = zaključek programa
- T = vklopi zaznavanje objektov
- F = izklopi zaznavanje objektov
